import flet as ft
from flet import KeyboardType
import sys
import os
from knitting import calc_diffed_maskpattern 





def main(page):

    # # Imports when runnin in web (Pyodide)
    # if sys.platform == 'emscripten': # check if run in Pyodide environment
    #     import micropip
    #     await micropip.install('more-itertools')


    # General app settings
    page.title = 'Knitter'
    #page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 25
    page.window_width = 500
    page.window_height = 800   

    if page.platform == 'windows':
        page.window_min_width = 400
        page.window_min_height = 600



#################### Functions #################### 

    def resource_path(relative_path):
        """ Get absolute path to resource, works for dev and for PyInstaller """
        
        base_path = ''
        
        try:
            # PyInstaller creates a temp folder and stores path in _MEIPASS
            base_path = sys._MEIPASS
        except Exception:
            
            # check if run in Pyodide (static web site) environment
            if sys.platform == 'emscripten':  
                # Remove first folder from path. Gets different locatin in web
                path = str(relative_path).split(r'/')
                relative_path = r'/'.join(path[1:])

        return os.path.join(base_path, relative_path)
       


    def set_focus(controller):
        """Set focus to provided controller element""" 
        controller.focus()



    def calc_mask_click(e):
        """Calculates knitting pattern and presents results on screen"""       

        # Calculate mask pattern if input is numeric
        if init_mask.value.isnumeric() and mask_diff.value.isnumeric():
            knitting_pattern = calc_diffed_maskpattern(int(init_mask.value), int(mask_diff.value))
            
            # Debug
            # ic(f'init mask: {init_mask.value}')
            # ic(f'inc/dec: {mask_diff.value}')
            # ic(knitting_pattern)

            # Clear result
            clear_result(e)

            # Present result
            for pattern in knitting_pattern:    
                result.controls.append(ft.Text(f'{pattern}',))
            
            # Update page
            page.update()


    def clear_result(e):
        """Clears result""" 
        result.controls.clear()
        page.update()
        
        # Debug
        # ic('clear')


    def clear_inputs(e):
        """Clears input fields""" 
        init_mask.value = ""
        mask_diff.value = ""
        page.update()
        


#################### Controllers #################### 

    logo = ft.Image(
        src=resource_path(f'assets/images/yarn2.png'),
        width=90,
        height=90,
        fit=ft.ImageFit.CONTAIN,
    )

    init_mask = ft.TextField(
        label="Initial mask amount",
        keyboard_type=KeyboardType.NUMBER,
        on_submit=lambda e: set_focus(mask_diff),
        on_focus=clear_inputs,
        max_length=3,
    )
    
    mask_diff = ft.TextField(
        label="Increase/decrease mask by amount",
        keyboard_type=KeyboardType.NUMBER,
        on_submit=calc_mask_click,
        max_length=3,
    )
    
    result = ft.Column(
        scroll=ft.ScrollMode.ALWAYS,
        height=400, 
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )


#################### Page #################### 

    page.add(        
        
        ft.Row(
            [ft.Text(
                "Knitter ",
                size=60
                ),
            ft.Container(
                content=logo,
                margin=0,
                padding=0,
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        ),
        
        init_mask,
        mask_diff,
        
        # Button for calculating masks
        ft.Row(
            [ft.Container(
                width=300,
                height=40,
                content=ft.ElevatedButton(
                    'Calculate masks', 
                    on_click=calc_mask_click
                    ),
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        ),        

        # Result box
        ft.Row(
            [ft.Container(
                padding=0,
                margin=10,
                expand=True,
                border_radius=ft.border_radius.all(8),
                bgcolor=ft.colors.SURFACE_VARIANT,
                content=result,
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            expand=True,
        ),

        ft.Row([
            ft.Text(
                'Use at own risk',
                size=5,
            ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )
    )




#################### App #################### 

ft.app(target=main,
       assets_dir="assets",
       route_url_strategy="hash",
       )




# Hot Reload
# flet run main.py -d
# flet run main.py --android


# flet pack main.py --icon "assets\images\yarn2.png" --name "Knitter" --distpath "D:\Python\Builds" --add-data "assets:assets" --product-name "Knitter" --file-description "This is the Knitter shit" --file-version 0.9.3 --company-name "DSM inc" --copyright "DSM copyright"

# flet publish main.py 

# flet publish --assets "assets\images" --distpath "D:\Python\Builds\KnitterWeb" --app-name "Knitter" --app-short-name "Knit" --app-description "Does knitting calculations" --base-url "knitter" --web-renderer html --use-color-emoji --route-url-strategy path main.py
# flet publish --assets "assets" --distpath "D:\Python\Builds\KnitterWeb" --app-name "Knitter" --app-short-name "Knit" --app-description "Does knitting calculations" --base-url "knitter" --web-renderer canvaskit --use-color-emoji --route-url-strategy path main.py
# flet publish main.py --distpath "D:\Python\Builds\KnitterWeb" --app-name "Knitter" --assets "assets" --route-url-strategy hash --base-url "knitter"


# flet publish main.py --distpath "D:\Python\Builds\WebApps\Knitter" --app-name "Knitter" --app-description "Does knitting calculations" --route-url-strategy hash --base-url "Knitter" --assets "assets"
# python -m http.server --directory D:\Python\Builds\WebApps