import re
from more_itertools import interleave_evenly


# Dev
# from icecream import ic


def calc_diffed_maskpattern(init_mask_cnt : int, diff_mask_cnt : int):
    """Calculates new knitting pattern with evenly distributed masks after increasing/reducing mask amount

    Args:
        init_mask_cnt (int): Number of masks originally
        diff_mask_cnt (int): Number of masks to reduce or increase

    Returns:
        str: knitting pattern with number of masks to knit before increasing/decreasing
    """

    # Exit function because divide by 0
    if diff_mask_cnt == 0:
        return
    
    # Calculates integer for masks and remainder
    base, rest = divmod(init_mask_cnt, diff_mask_cnt)
    
    # Generate a list, one element pr increase/decrease. Value is nr of masks to knit before adding/removing mask
    distribute = [base + (i < rest) for i in range(diff_mask_cnt)]
    
    # Split list into 2 smalles lists with 
    lst1 = distribute[:rest]
    lst2 = distribute[rest:]
    
    # Combines both lists into one. Evenly distributing values
    evenly_distributed = list(interleave_evenly([lst1, lst2]))

    # Creates a new list where equal sequencial numbers ar grouped   
    grouped = _group_equal_sequence(evenly_distributed)

    # Creates a string with knitting pattern
    knitting_pattern = _generate_knitting_pattern(grouped)   
    # ic(knitting_pattern)
    knitting_pattern = _group_two_by_two(knitting_pattern)
    
    knitting_pattern = combine_m1(knitting_pattern)

    return knitting_pattern
   
   


def combine_m1(knitting_pattern: list):
    """Combines standalon m1 wiht previous m1

    Args:
        knitting_pattern (list): knitting pattern

    Returns:
        list: knitting pattern with combined m1
    """
    result = []
 
    for i, pattern in enumerate(knitting_pattern):
        
        # Add first element
        if not result:
            
            # Convert to m2 instead of 2x(m1)
            if pattern[-4:] == '(m1)':
                new_pattern = re.sub(r'(\d*)x*\(m1\)', r'm\1', pattern)
                result.append(new_pattern)
                continue
            
            result.append(pattern)
            continue
        
        # Test if pattern is only m1 and maybe a multiplier
        if pattern[-4:] == '(m1)':
            multiplier  = re.match(r'(\d*)x*\(m1\)', pattern).group(1)

            # set multiplier to 1 if no group extracted from regex
            if multiplier == '':
                multiplier = '1'
            
            # Add multiplier to existing number (always 1)
            multiplier = int(multiplier) + 1

            # Replace previous element with added m1
            new_pattern = re.sub(r'k(\d+),m1', fr'k\1,m{multiplier}', result[-1])
            result[-1] = new_pattern
            continue

        result.append(pattern)

    return result



   
def _group_two_by_two(knitting_pattern : list):   
    """Group all adjacent two by two elements

    Args:
        knitting_pattern (list): list of elements

    Returns:
        list: grouped pattern as string
    """

    new_pattern = []
    i = 0
    multiplier = 1
    while i < len(knitting_pattern):
               
        cur_element = knitting_pattern[i]
        cur_combined_pattern = ''
        next_combined_pattern = ''

        # Combine 4 adjacent elements into 2 by 2 groups
        # Ensure loop index is not higher than list size
        if (i+1) < len(knitting_pattern):
            cur_combined_pattern = f'[ {knitting_pattern[i]}, {knitting_pattern[i+1]} ]'
            
            if (i+3) < len(knitting_pattern):
                next_combined_pattern = f'[ {knitting_pattern[i+2]}, {knitting_pattern[i+3]} ]'

        # Appends remaining elements to result, not possible to compare more groups
        else:
        # if (i+3) == len(knitting_pattern)
            new_pattern.append(f'{cur_element}')
            i += 1
            continue

        # Count number of equal groups
        if cur_combined_pattern == next_combined_pattern:
            multiplier += 1
            i += 2
            continue
                   
        
        if cur_combined_pattern != next_combined_pattern:
            
            # Create string with group count
            if multiplier >= 2:
                pattern = f'{multiplier}x{cur_combined_pattern}'
                multiplier = 1
                i += 1
            
            # Create string from current element
            else:
                pattern = f'{cur_element}'
            

            # Add string to result
            new_pattern.append(pattern)
        
        i += 1

    return new_pattern




def _group_equal_sequence(sequence: list):
    """Groups sequencial numbers in sequence

    Args:
        sequence (list): sequence of numbers

    Returns:
        list of lists: equal sequencial numbers grouped
    """

    grouped_seq = []
    for value in sequence:

        # If test on a list is false when list is empty
        # This placed first to avoid index out of range error when trying to access the last element in list [-1]
        # Testing if element 0 in the last element in list is equal to current value
        if grouped_seq and grouped_seq[-1][0] == value:
            grouped_seq[-1].append(value)
        else:
            grouped_seq.append([value])

    return grouped_seq




def _generate_knitting_pattern(sequence: list):
    """Creates knitting pattern

    Args:
        sequence (list): list of lists with grouped numbers

    Returns:
        list: knitting pattern as string elements
    """
    knitting_pattern = []
    for i in range(0, len(sequence), 1):
       
        # Number of repeating elements
        multiplier = len(sequence[i]) 
        
        # Create a knitting pattern
        if sequence[i][0] > 0:
            pattern = f'(k{sequence[i][0]},m1)'
        else:
            pattern = f'(m1)'

        # Add number of repeating elements as a multiplier to pattern
        if multiplier >= 2:
            # knitting_pattern = knitting_pattern + f'{multiplier}x(k{sequence[i][0]},m1), '
            knitting_pattern.append(f'{multiplier}x{pattern}')
            continue

        knitting_pattern.append(f'{pattern}')
        

    return knitting_pattern




#TODO kombinere m1 til forrige ledd

if __name__ == "__main__":
    
    # total_mask = 439
    # increase_mask_amount = 43
    
    total_mask = 43
    increase_mask_amount = 13

    maskpattern = calc_diffed_maskpattern(total_mask,increase_mask_amount)

    # ic(maskpattern)




    
    
# 2x(k10,m1), 
# (k11,m1), 4x(k10,m1), (k11,m1), 4x(k10,m1), 
# (k11,m1), 4x(k10,m1), (k11,m1), 4x(k10,m1),
# (k11,m1), 
# 3x(k10,m1),  
# (k11,m1), 4x(k10,m1), (k11,m1), 4x(k10,m1), 
# (k11,m1), 4x(k10,m1), 
# (k11,m1), 
# (k10,m1)


    
    #356-10
    #6x36
    #4x35
    #36,35,36,35,36,35,36,35,36,36
    #samme som under men trekker fra en maske
    
    #356-11
    #4x33
    #7x32
    #32,33,32,32,33,32,32,33,32,32,33
    #kode gir totalt 357 istedefor 356 altså legger til en maske for å få ting til å gå opp som er feil
    
    #278x17
    #6x17
    #11x16
    #16,17,16,16,17,16,16,17,16,16,17,16,16,17,16,16,17
    #Samme som over, men legger til 2 masker.
    
    #Ser bra riktig ut når leap blir et heltall